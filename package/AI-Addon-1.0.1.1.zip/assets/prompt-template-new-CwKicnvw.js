import"./modulepreload-polyfill-B5Qt9EMX.js";import{d as B,u as F,r as f,o as G,c as v,a as b,b as A,e as t,f as w,t as d,w as k,v as P,g as D,h as $,F as _,j as I,k as L,l as z,m as j}from"./vendor-DHP1Z6-g.js";import{g as U,a as V,P as E,_ as M,i as N}from"./i18n-DdP5wdW4.js";const W="modulepreload",q=function(n){return"/"+n},S={},J=function(p,h,g){let l=Promise.resolve();if(h&&h.length>0){document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),r=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));l=Promise.allSettled(h.map(s=>{if(s=q(s),s in S)return;S[s]=!0;const m=s.endsWith(".css"),y=m?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${s}"]${y}`))return;const i=document.createElement("link");if(i.rel=m?"stylesheet":W,m||(i.as="script"),i.crossOrigin="",i.href=s,r&&i.setAttribute("nonce",r),document.head.appendChild(i),m)return new Promise((x,T)=>{i.addEventListener("load",x),i.addEventListener("error",()=>T(new Error(`Unable to preload CSS for ${s}`)))})}))}function u(a){const r=new Event("vite:preloadError",{cancelable:!0});if(r.payload=a,window.dispatchEvent(r),!r.defaultPrevented)throw a}return l.then(a=>{for(const r of a||[])r.status==="rejected"&&u(r.reason);return p().catch(u)})},R=[{name:"ICIO 结构",title:"ICIO提示词结构",content:`
### 指令: 
[[指令:你希望模型执行的具体任务]]

### 背景 (选填): 
[[背景:上下文信息, 这可以引导模型做出更好的反应]]

### 输入数据 (选填): 
[[输入:告知模型需要处理的数据]]

### 输出指示 (选填): 
[[输出:告知模型我们要输出的类型或格式]]
      `,tags:["ICIO"]},{name:"CRISPE 结构",title:"CRISPE提示词结构",content:`
### 能力与角色: 
[[CR:你希望 ChatGPT 扮演怎样的角色]]

### 洞察: 
[[背景:上下文信息, 这可以引导模型做出更好的反应]]

### 任务: 
[[任务:你希望 ChatGPT 做什么]]

### 输出: 
[[输出:你希望 ChatGPT 以什么风格或方式回答你]]

### 实验: 
[[实验:要求 ChatGPT 为你提供多个答案]]
      `,tags:["CRISPE"]},{name:"BORE 结构",title:"BORE提示词结构",content:`
### 能力与角色: 
[[CR:你希望 ChatGPT 扮演怎样的角色]]

### 背景: 
[[背景:上下文信息, 这可以引导模型做出更好的反应]]

### 任务目标: 
[[目标:你希望 ChatGPT 做什么]]

### 关键结果: 
[[结果:让 ChatGPT 知道实现目标所需要达成的具体、可衡量的结果]]

### 实验: 
[[实验:通过试验来检验结果，并根据需要进行调整]]
      `,tags:["BORE"]},{name:"Szhans 结构",title:"Szhans提示词结构",content:`
### 任务目标: 
[[目标:你希望 ChatGPT 做什么]]

### 提供框架: 
[[示例:ChatGPT 的示例]]

### 目标受众: 
[[受众:什么类型的人会去读]]

### 语气风格: 
[[语气:比如幽默、严肃、正式...]]

### 参考: 
[[参考:作者/电影/书籍/其他的风格,比如斯蒂芬金]]

### 不要涉及以下内容: 
[[规避:（比如政治）]]
      `,tags:["Szhans"]},{name:"文生图完整结构",title:"文生图提示词结构",content:`
        [[主题]],[[画风]],[[风格]],[[画家]],[[分辨率]],[[额外细节]],[[色调]],[[光影]]
      `,tags:["文生图","MJ","SD"]},{name:"画人物结构",title:"文生图提示词结构",content:`
        [[人物主体特征：衣服、发型、五官、表情、肢体动作]],
        [[场景：室内/外、大场景、小细节]],
        [[环境：白天/黑夜、时间段、光照]],
        [[画幅及视角：距离、人物比例、观察视角]],
        [[画质:最佳质量, 超精细, 杰作, 高分辨率]],
        [[画风:插画风:插画, 绘画, 画笔; 二次元:动漫, 漫画; 写实:照片级真实感, 写实, 摄影]]
      `,tags:["文生图","MJ","SD","画人物"]}],O=[{name:"ICIOFramework",title:"ICIO PromptFramework",content:`
### Instruction: 
[[Instruction: The specific task you want the model to perform]]

### Context (Optional): 
[[Context: Background information that can guide the model to provide better responses]]

### Input Data (Optional): 
[[Input: Inform the model about the data it needs to process]]

### Output Guidance (Optional): 
[[Output: Specify the type or format of the output you expect]]
      `,tags:["ICIO"]},{name:"CRISPEFramework",title:"CRISPE PromptFramework",content:`
### Capability & Role: 
[[CR: What role you want ChatGPT to play]]

### Insight: 
[[Context: Background information that can guide the model to provide better responses]]

### Task: 
[[Task: What you want ChatGPT to do]]

### Output: 
[[Output: The style or manner in which you want ChatGPT to respond]]

### Experiment: 
[[Experiment: Ask ChatGPT to provide multiple answers]]
      `,tags:["CRISPE"]},{name:"BOREFramework",title:"BORE PromptFramework",content:`
### Capability & Role: 
[[CR: What role you want ChatGPT to play]]

### Context: 
[[Context: Background information that can guide the model to provide better responses]]

### Task Objective: 
[[Goal: What you want ChatGPT to do]]

### Key Results: 
[[Results: Let ChatGPT know the specific, measurable outcomes required to achieve the goal]]

### Experiment: 
[[Experiment: Test the results through trials and adjust as needed]]
      `,tags:["BORE"]},{name:"SzhansFramework",title:"Szhans PromptFramework",content:`
### Task Objective: 
[[Goal: What you want ChatGPT to do]]

### Provide Framework: 
[[Example: Examples for ChatGPT]]

### Target Audience: 
[[Audience: The type of people who will read this]]

### Tone & Style: 
[[Tone: E.g., humorous, serious, formal...]]

### Reference: 
[[Reference: Author/movie/book/other styles, e.g., Stephen King]]

### Avoid the Following: 
[[Avoid: (e.g., politics)]]
      `,tags:["Szhans"]},{name:"Text-to-Image FullFramework",title:"Text-to-Image PromptFramework",content:`
        [[Subject]], [[Art Style]], [[Style]], [[Artist]], [[Resolution]], [[Additional Details]], [[Color Tone]], [[Lighting]]
      `,tags:["Text-to-Image","MJ","SD"]},{name:"Character DrawingFramework",title:"Text-to-Image PromptFramework",content:`
        [[Character Features: Clothing, Hairstyle, Facial Features, Expression, Body Language]],
        [[Scene: Indoor/Outdoor, Large Scene, Small Details]],
        [[Environment: Day/Night, Time of Day, Lighting]],
        [[Aspect Ratio & Perspective: Distance, Character Proportion, Viewing Angle]],
        [[Quality: Best Quality, Ultra-Detailed, Masterpiece, High Resolution]],
        [[Art Style: Illustration: Illustration, Painting, Brushwork; Anime: Anime, Manga; Realistic: Photorealistic, Realistic, Photography]]
      `,tags:["Text-to-Image","MJ","SD","Character Drawing"]}];R.forEach(n=>{n.content=n.content.trim()});O.forEach(n=>{n.content=n.content.trim()});function K(n){return n==="zh"?R:O}const H={class:"container mx-auto p-4 max-w-4xl"},Q={class:"flex justify-between items-center mb-6 p-4 bg-white rounded-lg shadow-md sticky top-0 z-10"},X={class:"flex items-center"},Y={class:"text-indigo-600 hover:text-indigo-800 mr-4 transition-colors duration-200",href:"/sidepanel.html"},Z={class:"text-xl font-bold text-gray-800"},tt={class:"flex space-x-2"},et={class:"bg-white p-6 rounded-lg shadow-md mb-6 transition-all duration-200 hover:shadow-lg"},ot={class:"space-y-4"},at={class:"block text-gray-700 text-sm font-bold mb-2",for:"articleTitle"},nt=["placeholder"],rt={class:"block text-gray-700 text-sm font-bold mb-2",for:"articleContent"},st={class:"hs-dropdown relative inline-flex float-right"},lt={id:"hs-dropdown-default",type:"button",class:"hs-dropdown-toggle py-1 px-1 inline-flex items-center gap-x text-sm font-medium rounded-lg cursor-pointer border border-transparent text-blue-600 hover:text-blue-800 focus:outline-hidden focus:text-blue-800 active:text-blue-800 disabled:opacity-50 disabled:pointer-events-none dark:text-blue-500 dark:hover:text-blue-400 dark:focus:text-blue-400 dark:active:text-blue-400","aria-haspopup":"menu","aria-expanded":"false","aria-label":"Dropdown"},it={class:"hs-dropdown-menu transition-[opacity,margin] duration hs-dropdown-open:opacity-100 opacity-0 hidden z-999 min-w-60 bg-white shadow-md rounded-lg mt-2 dark:bg-neutral-800 dark:border dark:border-neutral-700 dark:divide-neutral-700 after:h-4 after:absolute after:-bottom-4 after:start-0 after:w-full before:h-4 before:absolute before:-top-4 before:start-0 before:w-full",role:"menu","aria-orientation":"vertical","aria-labelledby":"hs-dropdown-default"},dt={class:"p-1 space-y-0.5"},ut=["onClick"],ct=["placeholder"],pt={class:"text-gray-500 text-xs"},mt={class:"block text-gray-700 text-sm font-bold mb-2",for:"articleContent"},ht={class:"flex flex-wrap items-center gap-2 mb-3"},gt=["onClick"],ft={class:"relative"},vt=["placeholder"],bt=B({__name:"PromptTemplateNew",setup(n){const{t:p,locale:h}=F(),g=f(),l=f([]),u=f(""),a=f(""),r=f([]);let s=U("id");G(()=>{m()});async function m(){let o=await V();if(h.value=o,r.value=K(o),s){let e=await E.getInstance().getTemplateById(s);e&&(u.value=e.title,a.value=e.content,l.value=Array.from(Object.values(e.tags)))}}const y=o=>{const e=o.target;e.value.trim()&&(l.value.indexOf(e.value.trim())<0&&l.value.push(e.value.trim()),e.value="")},i=o=>{l.value.splice(o,1)};async function x(){if(!u.value.trim()||!a.value.trim()){g.value.show(p("promptTemplate.messages.fillRequired"));return}const o={title:u.value.trim(),content:a.value.trim(),tags:l.value,id:s||"",origin:"",originId:0,scope:"",hmc:"",usingTotal:0,favoriteTotal:0,createdAt:new Date};try{await E.getInstance().saveTemplates([o]),location.href="/sidepanel.html",g.value.show(p("promptTemplate.messages.saveSuccess"))}catch(e){g.value.show(p("promptTemplate.messages.saveFail")+" "+e)}}function T(o){u.value=o.title,a.value=o.content,l.value=[...o.tags]}return(o,e)=>(b(),v("div",H,[A(M,{ref_key:"toast",ref:g},null,512),t("div",Q,[t("div",X,[t("a",Y,[e[2]||(e[2]=t("i",{class:"fas fa-arrow-left mr-2"},null,-1)),w(" "+d(o.$t("promptTemplate.back")),1)])]),t("h3",Z,d(o.$t("promptTemplate.title")),1),t("div",tt,[t("button",{onClick:x,class:"bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-semibold py-2 px-4 rounded-lg shadow hover:shadow-md transition-all duration-200 cursor-pointer"},[e[3]||(e[3]=t("i",{class:"fas fa-save mr-2"},null,-1)),w(d(o.$t("promptTemplate.button.save")),1)])])]),t("div",et,[t("div",ot,[t("div",null,[t("label",at,d(o.$t("promptTemplate.form.title")),1),k(t("input",{class:"w-full rounded-lg border border-gray-300 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200",type:"text",id:"articleTitle",placeholder:o.$t("promptTemplate.form.titlePlaceholder"),"onUpdate:modelValue":e[0]||(e[0]=c=>u.value=c)},null,8,nt),[[P,u.value]])]),t("div",null,[t("label",rt,[w(d(o.$t("promptTemplate.form.content"))+" ",1),k(t("div",st,[t("button",lt,[w(d($(p)("promptTemplate.form.contentBtn"))+" ",1),e[4]||(e[4]=t("svg",{class:"hs-dropdown-open:rotate-180 size-4",xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"},[t("path",{d:"m6 9 6 6 6-6"})],-1))]),t("div",it,[t("div",dt,[(b(!0),v(_,null,I(r.value,c=>(b(),v("span",{onClick:z(C=>T(c),["prevent"]),class:"flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-gray-800 cursor-pointer hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100 dark:text-neutral-400 dark:hover:bg-neutral-700 dark:hover:text-neutral-300 dark:focus:bg-neutral-700",key:c.name},d(c.name),9,ut))),128))])])],512),[[D,r.value.length>0]])]),k(t("textarea",{class:"w-full rounded-lg border border-gray-300 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 max-h-[333px]",id:"articleContent",placeholder:o.$t("promptTemplate.form.contentPlaceholder"),rows:"6","data-hs-textarea-auto-height":"","onUpdate:modelValue":e[1]||(e[1]=c=>a.value=c)},null,8,ct),[[P,a.value]]),t("span",pt,d(o.$t("promptTemplate.paramHint")),1)]),t("div",null,[t("label",mt,d(o.$t("promptTemplate.form.tags")),1),t("div",ht,[(b(!0),v(_,null,I(l.value,(c,C)=>(b(),v("span",{key:C,class:"bg-indigo-100 text-indigo-800 text-sm font-medium py-1 px-3 rounded-full flex items-center"},[w(d(c)+" ",1),t("button",{onClick:wt=>i(C),class:"text-indigo-600 hover:text-indigo-800 ml-1.5 focus:outline-none"},e[5]||(e[5]=[t("i",{class:"icon iconfont icon-times text-xs"},null,-1)]),8,gt)]))),128))]),t("div",ft,[t("input",{class:"w-full rounded-lg border border-gray-300 pl-3 pr-10 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200",type:"text",placeholder:o.$t("promptTemplate.form.tagsPlaceholder"),onKeydown:L(y,["enter"])},null,40,vt),e[6]||(e[6]=t("span",{class:"absolute right-3 top-2.5 text-gray-400"},[t("i",{class:"fas fa-tag"})],-1))])])])])]))}});j(bt).use(N).mount("#app");J(()=>import("./vendor-DHP1Z6-g.js").then(n=>n.i),[]);
